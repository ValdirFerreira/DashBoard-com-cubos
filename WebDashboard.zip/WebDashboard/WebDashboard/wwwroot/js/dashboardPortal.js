﻿var objetodivItemDashBoard1 = new Object();

objetodivItemDashBoard1.contador = 0;

objetodivItemDashBoard1.CarregaItem = function () {


    cuboDashboard.CriaItem("divItemDashBoard1", "Meu 1 Teste", cuboDashboard.corItem.whide);

    cuboDashboard.CriaItem("divItemDashBoard2", "Meu 2 Teste", cuboDashboard.corItem.whide);

    cuboDashboard.CriaItem("divItemDashBoard3", "Meu 3 Teste", cuboDashboard.corItem.whide);

    cuboDashboard.CriaItem("divItemDashBoard4", "Meu 4 Teste", cuboDashboard.corItem.red);

    cuboDashboard.CriaItem("divItemDashBoard5", "Meu 5 Teste", cuboDashboard.corItem.purple);

    cuboDashboard.CriaItem("divItemDashBoard6", "Meu 6 Teste", cuboDashboard.corItem.grey);

    objetodivItemDashBoard1.AtualizaConteudo();

}

objetodivItemDashBoard1.CriarDiv = function (mumeroDiv) {
    var div1 = $("<div>");
    var span1 = $("<span>");
    span1.text("teste meu teste Div  " + mumeroDiv + " - " + objetodivItemDashBoard1.contador);
    div1.append(span1);
    div1.css("width", '290px');
    div1.css("height", '180px');
    div1.css("background-color", 'green');
    div1.css("border-radius", "7px");
    return div1;
}

objetodivItemDashBoard1.AtualizaConteudo = function () {

    $("#divItemDashBoard1Conteudo").html(objetodivItemDashBoard1.CriarDiv(1));

    $("#divItemDashBoard2Conteudo").html(objetodivItemDashBoard1.CriarDiv(2));

    $("#divItemDashBoard3Conteudo").html(objetodivItemDashBoard1.CriarDiv(3));

    setTimeout(objetodivItemDashBoard1.AtualizaConteudo, 3000);
    objetodivItemDashBoard1.contador++;
}

$(function () {
    objetodivItemDashBoard1.CarregaItem();
});






