﻿/*************************************
 * cuboDashboard
 * Criado por Valdir ferreira
 * Data Criação : 22/05/2020 : 02:00 na pandemia
 * Objetivo e criar cubos personalizados na tela
 *************************************/
var cuboDashboard = new Object();

cuboDashboard.corItem =
{
    grey: 0,
    white: 1,
    red: 2,
    purple: 3
};

cuboDashboard.CriaItem = function (idDiv, titulo, corItem, conteudo = "") {
   
    var _titulo = "Sem Titulo";

    if (titulo == null || titulo == "" || titulo == undefined) {
        titulo = _titulo;
    }

    var cores = cuboDashboard.ObterCoresItem(corItem);

    var divTopo = $('<div>');
    divTopo.addClass('ItemTop');
    divTopo.css('color', cores.corTitulo);

    var divCabecalho = $('<div>');
    divCabecalho.addClass('itemCabecalho');

    var divTitulo = $('<div>');
    divTitulo.text(titulo);
    divTitulo.addClass('itemTitulo');

    var divControles = $('<div>');
    divControles.addClass('itemControle');

    cuboDashboard.ConfigurarBotoes(idDiv, divControles);

    var divConteudo = $('<div>');
    divConteudo.addClass('itemConteudo');
    divConteudo.attr('id', idDiv + 'Conteudo');
    divConteudo.css('overflow', 'auto');

    $("#" + idDiv).html('');
    $("#" + idDiv).append(divTopo);
    divTopo.append(divCabecalho);
    divCabecalho.append(divTitulo);
    divTitulo.append(divControles);
    divConteudo.css('height', '180px');
    divConteudo.append(conteudo);
    divTopo.append(divConteudo);
    $("#" + idDiv).css('background-color', cores.corFundo);
    $("#" + idDiv).addClass('efeitoDiv');

}

cuboDashboard.ConfigurarBotoes = function (idDiv, divControle) {

    var btnMinimizar = cuboDashboard.CriarBotao(idDiv, divControle, 'img/minimizar.png', 'minMax', 'itemBotaoMax');
    btnMinimizar.click(function () {
        cuboDashboard.ModoBotao(idDiv, this);
    });

    var btnFechar = cuboDashboard.CriarBotao(idDiv, divControle, 'img/fechar.png', 'fechar');
    btnFechar.click(function () {
        $('#' + idDiv).hide('slow', function () {
            var divPlugin = $(this).parent();
            divPlugin.remove();
        });
    });
};

cuboDashboard.ObterCoresItem = function (corItem) {
    var retorno = { corFundo: 'grey', corTexto: 'white', corTitulo: 'white' };

    switch (corItem) {

        case cuboDashboard.corItem.grey:
            retorno.corFundo = 'rgb(105,105,105)';
            retorno.corTexto = 'white';
            retorno.corTitulo = 'white';
            break;
        case cuboDashboard.corItem.white:
        default:
            retorno.corFundo = 'rgb(248,248,255)';
            retorno.corTexto = 'black';
            retorno.corTitulo = 'black';
            break;
        case cuboDashboard.corItem.red:
            retorno.corFundo = 'rgb(255,0,0)';
            retorno.corTexto = '#F8F8FF';
            retorno.corTitulo = 'black';
            break;

        case cuboDashboard.corItem.purple:
            retorno.corFundo = 'rgb(128,0,128)';
            retorno.corTexto = '#F8F8FF';
            retorno.corTitulo = 'black';
            break;
    }

    return retorno;
};

cuboDashboard.CriarBotao = function (idDiv, divControle, img, sufixo, classe = "") {
    var novoBotao = $('<img>');
    var idBotao = 'Botao' + idDiv + sufixo;

    novoBotao.attr('id', idBotao);
    var classeBotao = "itemBotao";

    if (classe != "") {
        classeBotao = classe;
    }

    novoBotao.addClass(classeBotao);
    novoBotao.attr('divContainer', idDiv);
    novoBotao.attr('src', img);

    divControle.append(novoBotao);

    return novoBotao;
};

cuboDashboard.ModoBotao = function (idDiv, botao) {

    var className = $('#' + botao.id).attr('class');
    if (className == "itemBotaoMax") {
        $('#' + idDiv + "Conteudo").hide('slow', function () {
            $('#' + botao.id).attr('src', 'img/maximizar.png');
        });

        $('#' + botao.id).removeClass('itemBotaoMax');
        $('#' + botao.id).addClass('itemBotao');
    }

    if (className == "itemBotao") {
        $('#' + idDiv + "Conteudo").animate({ height: '180px' }, 500, 'swing', function () {
            $('#' + idDiv + "Conteudo").show('slow');
            $('#' + botao.id).attr('src', 'img/minimizar.png');
            $('#' + botao.id).attr('minimizado', 'false');
        });

        $('#' + botao.id).addClass('itemBotaoMax');
        $('#' + botao.id).removeClass('itemBotao');
    }
}




